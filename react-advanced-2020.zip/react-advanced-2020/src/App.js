import React from "react";
import Setup from "./tutorial/7-prop-drilling/setup/1-prop-drilling";
function App() {
  return (
    <div className="container">
      <Setup />
    </div>
  );
}

export default App;
